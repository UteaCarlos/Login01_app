package com.example.app03_imc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
