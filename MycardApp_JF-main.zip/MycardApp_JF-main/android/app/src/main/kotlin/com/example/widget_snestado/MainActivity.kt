package com.example.widget_snestado

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
