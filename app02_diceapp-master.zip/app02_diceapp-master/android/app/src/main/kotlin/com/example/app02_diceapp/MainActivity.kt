package com.example.app02_diceapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
